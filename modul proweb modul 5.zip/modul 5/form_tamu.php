<html>

<head>
    <title> Form Tamu </title>
</head>

<body>
    <form method="POST" action="input_tamu.php">
        Nama :<br><input type="text" name="nama" placeholder="Nama"><br>
        Email :<br><input type="text" name="email" placeholder="Email"><br>
        Pesan :<br> <textarea name="pesan" placeholder="Pesan" rows="5" cols="25"></textarea><br>
        <input type="submit" name="submit" value="kirim">
    </form>
</body>

</html>