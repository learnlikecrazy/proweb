<html>

<head>
    <title>pengelolaan data toko film serba ada</title>
</head>

<body>
    <center>
        <h2>pengelolaan data toko film serba ada</h2>
        <hr>
    </center>
    <?php
    if (isset($_GET["PROSES"])) {
        include("basisdata.php");
        switch ($action) {
            case "TAMBAH":
                $judul = $_POST['judul'];
                $jenis = $_POST['jenis'];
                $nama_gmb = $_POST['nama_gmb'];
                $sutradara = $_POST['sutradara'];
                $pemain_utama = $_POST['pemain_utama'];
                $harga = $_POST['harga'];
                $sekilas = $_POST['sekilas'];
                $thn_terbit = $_POST['thn_terbit'];
                $query = "INSERT INTO dvd (id_film,judul,jenis,nama_gmb,sutradara,
 pemain_utama,harga,sekilas,thn_terbit)";
                $query .= "VALUES
('',$judul','$jenis','$nama_gmb','$sutradara',
 '$pemain_utama','$harga','$sekilas','$thn_terbit')";
                $hasil_mysql = mysqli_query($sambungan, $query);
                $pesan = "data berhasil ditambahkan";
                break;
            case "UBAH":
                $query = "UPDATE dvd SET judul='$judul',jenis='$jenis'";
                $query .= "nama_gmb='$nama_gmb',sutradara='$sutradara',";
                $query .= "pemain_utama='$pemain_utama',sekilas='$sekilas',";
                $query .= "harga='$harga',thn_terbit='$thn_terbit' ";
                $query .= "WHERE id_film like $id_film";
                $hasil_mysql = mysqli_query($sambungan, $query);
                $pesan = "data berhasil diubah";
                break;
            case "HAPUS":
                $query = "DELETE FROM dvd WHERE id_dvd like $id_dvd";
                $hasil_mysql = mysqli_query($sambungan, $query);
                $pesan = "data berhasil dihapus";
                break;
        }
        print("<h3>$pesan</h3>");
    } ?>