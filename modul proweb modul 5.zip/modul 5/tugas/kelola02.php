<html>

<head>
    <title>pengelolaan data toko film serba ada</title>
</head>

<body>
    <center>
        <h2>Pengelolaan Toko Film Serba Ada</h2>
        <hr>
        <h3><? print("$action"); ?> DATA FILM</h3>
    </center>
    <form method=post action=proses.php>
        <?php
        include("basisdata.php");
        if(isset($_GET["TAMBAH"])&& isset($_GET["id"])){
        if ($action == "TAMBAH") {
            $id_film = "";
            $judul = "";
            $jenis = "";
            $nama_gmb = "";
            $sutradara = "";
            $pemain_utama = "";
            $harga = "";
            $thn_terbit = "";
        } else {
            $query = "SELECT * FROM dvd WHERE id_film = '$id'";
            $hasil_mysql = mysqli_query($sambungan, $query);
            $baris = mysqli_fetch_row($hasil_mysql);
            $id_film = $baris[0];
            $judul = $baris[1];
            $jenis = $baris[2];
            $nama_gmb = $baris[3];
            $sutradara = $baris[4];
            $pemain_utama = $baris[5];
            $harga = $baris[6];
            $sekilas = $baris[7];
            $thn_terbit = $baris[8];
        }
        print("<input type=hidden name=id_film value=$id>
 <input type=hidden name=action value=$action>");
    }?>
        Judul Film : <input type=text name=judul size="20" maxlength="30" value="<?php $judul; ?>"><br>
        Sekilas Isi : <textarea name=sekilas><?php $sekilas; ?></textarea><br>
        Jenis Film : <input type=text name=jenis size="20" maxlength="20" value="<?php $jenis; ?>"><br>
        Nama File Gambar : <input type=text name=nama_gmb size="20" maxlength="20" value="<?php $nama_gmb; ?>"><br>
        Nama Sutradara : <input type=text name=sutradara size="30" maxlength="30" value="<?php $sutradara; ?>"><br>
        Nama Pemain_Utama : <input type=text name=penulis size="30" maxlength="30" value="<?php $pemain_utama; ?>"><br>
        Harga : Rp <input type=text name=harga size="20" maxlength="20" value="<?php $harga; ?>"><br>
        Tahun Terbit : <input type=text name=thn_terbit size="20" maxlength="20" value="<?php $thn_terbit; ?>"><br>
        <input type=submit value="PROSES" name="submit">
    </form>
    <center>
        <hr>
        Alamat : Jl. Pelan 2 Banyak Anak-Anak<br>
        e-mail : <a href=mailto:dvdstore@serba-ada.com>dvdstore@ serba-
            ada.com</a>
    </center>
</body>

</html>