<?php
session_start();
if (empty($_SESSION['username'])) {
    header("location:index.php?pesan=belum_login");
}
?>
<html>

<head>
    <title>toko film serba ada</title>
</head>

<body>
    <center>
        <h2>Selamat Datang di Toko Film Serba ada</h2>
        <hr>
    </center>
    <p>
    <h3>Pilih kategori film yang anda cari</h3>
    </p>
    <ul>
        <?php
        //menyertakan isi dari suatu file
        include("basisdata.php");
        //mengambil data
        $query = "SELECT DISTINCT jenis FROM dvd";
        $hasil_mysql = mysqli_query($sambungan,$query);
        //mengambil data setiap baris
        while ($baris = mysqli_fetch_row($hasil_mysql)) {
            $jenis = $baris[0];
            print("<li> <a href=kategori.php?jenis=$jenis>$jenis</a></li>");
        }
        ?>
    </ul>
    <center>
        <hr><a href=kelola01.php>pengelolaan</a> | <a href=logout.php>Logout</a><br>
        Alamat : Jl. Pelan 2 Banyak Anak-Anak<br>
        e-mail : <a href=mailto:dvdstore@serba-ada.com>dvdstore@ serbaada.com</a>
    </center>
</body>

</html>