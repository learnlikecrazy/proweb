<html>

<head>
    <title>pengelolaan data toko film serba ada</title>
</head>

<body>
    <center>
        <h2>pengelolaan data toko film serba ada</h2>
        <hr>
    </center>
    <?php
    // if (isset($_GET["action"])) {
        $action = $_POST["action"];
        include("basisdata.php");
        switch ($action) {
            case "TAMBAH":
                $judul = $_POST['judul'];
                $jenis = $_POST['jenis'];
                $nama_gmb = $_POST['nama_gmb'];
                $sutradara = $_POST['sutradara'];
                $pemain_utama = $_POST['pemain_utama'];
                $harga = $_POST['harga'];
                $sekilas = $_POST['sekilas'];
                $thn_terbit = $_POST['thn_terbit'];
                
                $query = "INSERT INTO dvd (id_film,judul,jenis,nama_gmb,sutradara,
 pemain_utama,harga,sekilas,thn_terbit)";
                $query .= "VALUES
('','$judul','$jenis','$nama_gmb','$sutradara',
 '$pemain_utama','$harga','$sekilas','$thn_terbit')";
                $hasil_mysql = mysqli_query($sambungan, $query);
                if($hasil_mysql) {
                    $pesan = "data berhasil ditambahkan";
                } else {
                    $pesan = "data gagal ditambahkan";
                }
                
                break;
            case "UBAH":
                $id_film = $_POST['id_film'];
                $judul = $_POST['judul'];
                $jenis = $_POST['jenis'];
                $nama_gmb = $_POST['nama_gmb'];
                $sutradara = $_POST['sutradara'];
                $pemain_utama = $_POST['pemain_utama'];
                $harga = $_POST['harga'];
                $sekilas = $_POST['sekilas'];
                $thn_terbit = $_POST['thn_terbit'];

                $query = "UPDATE dvd SET judul='$judul',jenis='$jenis',";
                $query .= "nama_gmb='$nama_gmb',sutradara='$sutradara',";
                $query .= "pemain_utama='$pemain_utama',sekilas='$sekilas',";
                $query .= "harga='$harga',thn_terbit='$thn_terbit'";
                $query .= "WHERE id_film = '$id_film'";
                $hasil_mysql = mysqli_query($sambungan, $query);
                var_dump($query);
                if($hasil_mysql) {
                    $pesan = "data berhasil diupdate";
                } else {
                    $pesan = "data gagal diupdate";
                }
                break;
            case "HAPUS":
                $id_film = $_POST['id_film'];
                $query = "DELETE FROM dvd WHERE id_film like $id_film";
                $hasil_mysql = mysqli_query($sambungan, $query);
                if($hasil_mysql) {
                    $pesan = "data berhasil dihapus";
                } else {
                    $pesan = "data gagal dihapus";
                }
                break;
        }
        print("<h3>$pesan</h3>");
        header("location:index.php");
    // } ?>