<?php
session_start();
if (empty($_SESSION['username'])) {
    header("location:index.php?pesan=belum_login");
}
?>
<html>

<head>
    <title>pengelolaan data toko film serba ada</title>
</head>

<body>
    <center>
        <h2>Pengelolaan Toko Film Serba Ada</h2>
        <hr>
        <h3><? print("$action"); ?> DATA FILM</h3>
    </center>
    <form method=post action=proses.php>
        <?php
        include("basisdata.php");
        $action = $_POST["action"];
        if ($action == "TAMBAH") {
            $id_film = "";
            $sekilas = "";
            $judul = "";
            $jenis = "";
            $nama_gmb = "";
            $sutradara = "";
            $pemain_utama = "";
            $harga = "";
            $thn_terbit = "";
        } else {
            $id = $_POST["id"];
            $query = "SELECT * FROM dvd WHERE id_film = '$id'";
            $hasil_mysql = mysqli_query($sambungan, $query);
            $baris = mysqli_fetch_row($hasil_mysql);
            $id_film = $baris[0];
            $judul = $baris[1];
            $sekilas = $baris[2];
            $jenis = $baris[3];
            $nama_gmb = $baris[4];
            $sutradara = $baris[5];
            $pemain_utama = $baris[6];
            $harga = $baris[7];
            $thn_terbit = $baris[8];
        }
        print("<input type=hidden name=id_film value=$id_film>
 <input type=hidden name=action value=$action>");

    ?>
        Judul Film : <input type=text name=judul size="20" maxlength="30" value="<?php echo $judul; ?>"><br>
        Sekilas Isi : <textarea name=sekilas><?php echo $sekilas; ?></textarea><br>
        Jenis Film : <input type=text name=jenis size="20" maxlength="20" value="<?php echo $jenis; ?>"><br>
        Nama File Gambar : <input type=text name=nama_gmb size="20" maxlength="20" value="<?php echo $nama_gmb; ?>"><br>
        Nama Sutradara : <input type=text name=sutradara size="30" maxlength="30" value="<?php echo $sutradara; ?>"><br>
        Nama Pemain Utama : <input type=text name=pemain_utama size="30" maxlength="30" value="<?php echo $pemain_utama; ?>"><br>
        Harga : Rp <input type=text name=harga size="20" maxlength="20" value="<?php echo $harga; ?>"><br>
        Tahun Terbit : <input type=text name=thn_terbit size="20" maxlength="20" value="<?php echo $thn_terbit; ?>"><br>
        <input type=submit value="PROSES" name="submit">
    </form>
    <center>
        <hr>
        Alamat : Jl. Pelan 2 Banyak Anak-Anak<br>
        e-mail : <a href=mailto:dvdstore@serba-ada.com>dvdstore@ serba-
            ada.com</a>
    </center>
</body>

</html>