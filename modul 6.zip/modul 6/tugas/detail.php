<html>

<head>
    <title>toko film serba ada</title>
</head>

<body>
    <center>
        <h2>Selamat Datang di Toko Film Serba Ada</h2>
        <hr>
    </center>
    <h3>Berikut ini detail film yang anda pilih</h3>
    <table border=1>
        <?php
        if(isset($_GET["id"]))
        {
        $id = $_GET["id"];
        include("basisdata.php");
        $query = "SELECT * FROM dvd WHERE id_film=$id";
        $hasil_mysql = mysqli_query($sambungan, $query);
        $baris = mysqli_fetch_row($hasil_mysql);
        $judul = $baris[1];
        $sekilas = $baris[2];
        $jenis = $baris[3];
        $nama_gmb = $baris[4];
        $sutradara = $baris[5];
        $pemain_utama = $baris[6];
        $harga = $baris[7];
        $thn_terbit = $baris[8];
        }
        ?>
        <tr valign="top">
            <td><img src=./image/<?php print("$nama_gmb"); ?> height=150></td>
            <td>
                <p>JUDUL<br><i><b><?php print("$judul"); ?></b></i></p>
                <p><i><b><?php print("$sekilas"); ?></b></i></p>
                <p>JENIS<br><i><b><?php print("$jenis"); ?></b></i></p>
                <p>SUTRADARA<br><i><b><?php print("$sutradara"); ?></b></i></p>
                <p>PEMAIN UTAMA<br><i><b><?php print("$pemain_utama"); ?></b></i></p>
                <p>HARGA<br><i><b>Rp <?php print("$harga"); ?></b></i></p>
                <p>TAHUN TERBIT<br><i><b><?php print("$thn_terbit"); ?></b></i></p>
            </td>
        </tr>
    </table><br>
    <center>
        <hr>
        Alamat : Jl. Pelan 2 Banyak Anak-Anak<br>
        e-mail : <a href=mailto:dvdstore@serba-ada.com>dvdstore@ serba-
            ada.com</a>
    </center>
</body>

</html>