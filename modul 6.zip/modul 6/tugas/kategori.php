<?php
session_start();
if (empty($_SESSION['username'])) {
    header("location:index.php?pesan=belum_login");
}
?>
<html>

<head>
    <title>toko film serba ada</title>
</head>

<body>
    <center>
        <h2>Selamat Datang di Toko Film Serba ada </h2>
        <hr>
    </center>
    <?php
    if(isset($_GET["jenis"]))
    {
    $jenis = $_GET["jenis"];
    print("<h3>Berikut ini daftar film berdasarkan kategori $jenis</h3>");
    print("<table border=1>");
    include("basisdata.php");
    $query = "SELECT id_film,judul,nama_gmb,sutradara FROM dvd ";
    $query .= "WHERE jenis='$jenis'";
    $hasil_mysql = mysqli_query($sambungan,$query);
    while ($baris = mysqli_fetch_row($hasil_mysql)) {
        $id_film = $baris[0];
        $judul = $baris[1];
        $nama_gmb = $baris[2];
        $sutradara = $baris[3];
        print("<tr><td><img src=./image/$nama_gmb height=50></td>");
        print("<td><b><a href=detail.php?id=$id_film>$judul</a></b>
 <br>$sutradara</td></tr>");
    }
    print("</table>");
}?>
    <center>
        <hr>
        Alamat : Jl. Pelan 2 Banyak Anak-Anak<br>
        e-mail : <a href=mailto:dvdstore@serba-ada.com>dvdstore@ serbaada.com</a>
    </center>
</body>

</html>