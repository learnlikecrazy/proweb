<html>
 <head>
 <title>keluarannya</title>
 </head>
<body>
<?php
echo "Hai, $_POST[nama] <br>";
echo "$_POST[sekolah] memang top";
?>
</body>
</html>