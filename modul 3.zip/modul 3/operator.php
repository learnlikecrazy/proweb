<html>
<head>
 <title>OPERATOR</title>
</head>
<body>
 <?php $Harga = 100; $Pengunjung = 8;
 echo "Jumlah pengunjung hari ini : $Pengunjung";
 echo "<br>Total Pendapatan : "; echo $Harga*$Pengunjung;
 ?>
</body>
</html>