<html>
 <head>
<title>Kondisional</title>
 </head>
 <body>
 <?php
 $Hari = date( 'l' );
 if ($Hari == "Tuesday")
 {
 echo "Hari yang menyenangkan";
 }
 else
 {
 echo "Hari yang melelahkan";
 }
 ?>
 </body>
</html>