<html>
<head>
 <title>Variabel</title>
</head>
<body>
<?php
/* deklarasi variabel */
$tanggal = date ("d F Y");
$nama = "Praktikan" ;
/*memanggil variabel tanggal*/
echo("$tanggal<br>");
/* memanggil variabel nama */
echo("$nama, Selamat datang di dunia webmaster");
?>
</body>
</html>
