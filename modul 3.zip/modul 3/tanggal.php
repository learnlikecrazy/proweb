<html>
 <head>
 <title>Tanggal</title>
 </head>
<body>
Tanggal : <?php echo(date("d F Y ")); ?>
</body>
</html>