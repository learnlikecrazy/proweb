<?php 
//luas segitiga
$a = 2;
$t = 4;
$luas_segitiga = 0.5 * $a * $t;
echo "Luas Segitiga adalah $luas_segitiga <br>";

//Volume Kubus
$s = 4;
$volume_kubus = $s *$s *$s;
echo "Volume Kubus adalah $volume_kubus"


?>