<html>
 <head>
 <title>Example</title>
 </head>
 <body>
 <?php echo "Hi, I'm a PHP script!"; ?>
 </body>
</html>
