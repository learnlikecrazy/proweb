<html>
 <head>
 <title>Masukan</title>
 </head>
<body>
 <form action="keluaran.php" method="post">
Nama Anda :<br> <input type="text" name="nama"><br><br>
Kuliah di :<br> <input type="text" name="sekolah"><br><br>
<input type="submit"> <input type="reset">
 </form>
</body>
</html>