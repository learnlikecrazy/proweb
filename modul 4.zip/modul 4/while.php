<html>
<head> <title>OPERATOR</title> </head>
<body>
 <?php
 $i = 1;
 while ($i<=7)
 {
 echo "$i<BR>";
 $i++;
 }
?>
</body>
</html>