<html>
<head>
 <title>Do While</title>
</head>
<body>
 <?php
 $i = 1;
 do
 {
 echo "$i<br>";
 $i++;
 } while ($i<=7)
 ?>
</body>
</html>