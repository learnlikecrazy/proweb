<html>
 <head>
 <title>Masukan</title>
 </head>
<body>
 <form action="hasil.php" method="post">
Masukkan Nama Anda :<br> 
<input type="text" name="nama">
<br><br>
Jumlah Anak Ayam :<br> 
<input type="text" name="jumlah">
<br><br>
<input type="submit"> <input type="reset">
 </form>
</body>
</html>