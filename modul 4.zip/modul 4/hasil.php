<?php 
$nama = $_POST['nama'];
$jumlah = $_POST['jumlah'];
echo "Anak Ayam $nama ada $jumlah Ekor <br>";
for($i = $jumlah; $i>=1; $i--){
if($i==1){
    $tinggal = "Induknya";
}else{
    $tinggal = $i-1;
}
echo "Anak Ayam turun $i mati satu tinggal $tinggal <br>";
}
?>