<html>
<head>
 <title> IF </title>
</head>
<body>
 <?php
 $X=100;
 $Y=50;
 If ($X > $Y)
 {
 echo "X Lebih besar dari Y";
 }
 ?>
</body>
</html>