<html>
<head> <title> Pengulangan </title> </head>
<body>
 <?php
 For ($i=3; $i<=7; $i++)
 {echo "<font size=$i> ERZA </font><br>";
 }
 ?>
</body>
</html>