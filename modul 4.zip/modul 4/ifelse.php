<html>
<head> <title>OPERATOR</title> </head>
<body>
 <?php
 $X=100;
 $Y=500;
 If ($X > $Y)
 {
 echo "X Lebih besar dari Y";
 }
else
 {
 echo "X Lebih kecil dari Y";
 }
 ?>
</body>
</html>